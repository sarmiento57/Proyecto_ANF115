from django.contrib import admin
from .models import Ciuu, Empresa, Venta

# Register your models here.
admin.site.register(Ciuu)
admin.site.register(Empresa)
admin.site.register(Venta)

