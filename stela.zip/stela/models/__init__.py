#Aqui se importan los modelos
#Este archivo indica que este directorio es un paquete Python
#crea los modelos dentro de este paquete
from .empresa import *
from .ciiu import *
from .venta import *